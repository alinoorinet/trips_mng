<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name')); ?></title>
        <link rel="icon" type="image/x-icon" href="/img/icon.png">
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    </head>
    <body>
        <div id='root'></div>
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.jsx'); ?>
    </body>
</html>
<?php /**PATH E:\GitHub\Trip_Mng\resources\views/welcome.blade.php ENDPATH**/ ?>